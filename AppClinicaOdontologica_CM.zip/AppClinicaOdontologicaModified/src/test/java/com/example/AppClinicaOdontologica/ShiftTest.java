package com.example.AppClinicaOdontologica;

import org.junit.FixMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@FixMethodOrder
@RunWith(SpringRunner.class)
@SpringBootTest
public class ShiftTest {
}
